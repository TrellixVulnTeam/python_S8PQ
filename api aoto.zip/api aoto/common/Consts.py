"""
接口全局变量

"""

# 接口全局配置
API_ENVIRONMENT_DEBUG = 'debug'
API_ENVIRONMENT_RELEASE = 'release'

# 接口响应时间list，单位毫秒
STRESS_LIST = []

# 接口执行结果list
RESULT_LIST = []

#a["public_image_name"].find(want_name) != -1: